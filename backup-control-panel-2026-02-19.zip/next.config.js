/** @type {import('next').NextConfig} */
const nextConfig = {
  /* خيارات التكوين هنا */
}

module.exports = nextConfig