import React from "react";

export default function EditOwnerAssociationPage() {
  return (
    <div style={{padding:'2em',textAlign:'center',color:'#1976d2',fontWeight:600,fontSize:'1.2em'}}>
      صفحة تعديل بيانات اتحاد الملاك (تحت الإنشاء)
    </div>
  );
}
