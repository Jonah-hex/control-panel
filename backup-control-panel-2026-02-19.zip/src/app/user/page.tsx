'use client'

export default function UserPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">صفحة المستخدم</h1>
        <p className="text-gray-600">هذه صفحة المستخدم</p>
      </div>
    </div>
  )
}