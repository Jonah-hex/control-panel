# 🏢 دليل حفظ بيانات العمارة الكامل
# Complete Building Data Save Guide

## 📋 المحتويات | Contents

1. [البيانات التي يتم حفظها](#data-saved)
2. [الجداول المستخدمة](#tables-used)
3. [السكيمات المطلوبة](#required-schemas)
4. [خطوات التطبيق](#implementation-steps)
5. [حل المشاكل](#troubleshooting)

---

## 📊 البيانات التي يتم حفظها | Data Being Saved

### 1️⃣ جدول Buildings (37 حقل)

#### المعلومات الأساسية (6 حقول)
- ✅ `name` - اسم العمارة (مطلوب)
- ✅ `plot_number` - رقم القطعة (مطلوب)
- ✅ `neighborhood` - الحي
- ⚠️ `address` - العنوان (غير مفعّل حالياً - يحتاج تحديث السكيما)
- ✅ `description` - الوصف
- ✅ `phone` - رقم الهاتف

#### تفاصيل البناء (9 حقول)
- ✅ `total_floors` - عدد الطوابق (محسوب تلقائياً)
- ✅ `total_units` - عدد الوحدات (محسوب تلقائياً)
- ✅ `reserved_units` - الوحدات المحجوزة
- ✅ `parking_slots` - مواقف السيارات
- ✅ `driver_rooms` - غرف السائقين
- ✅ `elevators` - المصاعد
- ✅ `street_type` - نوع الشارع (one/two/corner)
- ✅ `building_facing` - واجهة العمارة (north/south/east/west)
- ✅ `year_built` - سنة البناء

#### المعلومات القانونية (4 حقول)
- ✅ `build_status` - حالة البناء (ready/under_construction)
- ✅ `deed_number` - رقم الصك
- ✅ `land_area` - مساحة الأرض
- ✅ `building_license_number` - رقم رخصة البناء

#### معلومات التأمين (2 حقول)
- ✅ `insurance_available` - وجود تأمين
- ✅ `insurance_policy_number` - رقم وثيقة التأمين

#### عدادات المرافق (4 حقول)
- ✅ `has_main_water_meter` - وجود عداد مياه رئيسي
- ✅ `water_meter_number` - رقم عداد المياه
- ✅ `has_main_electricity_meter` - وجود عداد كهرباء رئيسي
- ✅ `electricity_meter_number` - رقم عداد الكهرباء

#### معلومات الحارس (7 حقول)
- ✅ `guard_name` - اسم الحارس
- ✅ `guard_phone` - رقم هاتف الحارس
- ✅ `guard_room_number` - رقم غرفة الحارس
- ✅ `guard_id_photo` - صورة هوية الحارس
- ✅ `guard_shift` - نوبة العمل
- ✅ `guard_has_salary` - وجود راتب
- ✅ `guard_salary_amount` - مبلغ الراتب

#### بيانات JSONB (2 حقول)
- ✅ `floors_data` - بيانات الطوابق والوحدات (JSONB)
- ✅ `owner_association` - بيانات اتحاد الملاك (JSONB - 12 حقل فرعي)

#### بيانات إضافية (4 حقول)
- ✅ `google_maps_link` - رابط خرائط جوجل
- ✅ `image_urls` - روابط الصور (Array)
- ✅ `owner_id` - معرف المالك (تلقائي)
- ✅ `created_at` - تاريخ الإنشاء (تلقائي)

### 2️⃣ اتحاد الملاك JSONB (12 حقل فرعي)

عند تفعيل `hasAssociation = true`:
- ✅ `hasAssociation` - وجود اتحاد ملاك
- ✅ `managerName` - اسم المدير
- ✅ `registrationNumber` - رقم التسجيل
- ✅ `registeredUnitsCount` - عدد الوحدات المسجلة بالاتحاد ⭐ NEW
- ✅ `iban` - رقم الآيبان
- ✅ `accountNumber` - رقم الحساب
- ✅ `contactNumber` - رقم التواصل
- ✅ `startDate` - تاريخ البداية
- ✅ `endDate` - تاريخ النهاية
- ✅ `monthlyFee` - الرسوم الشهرية
- ✅ `includesElectricity` - شامل الكهرباء
- ✅ `includesWater` - شامل المياه

### 3️⃣ جدول Units (17 حقل لكل وحدة)

يتم إنشاء صف لكل وحدة في جميع الطوابق:
- ✅ `building_id` - معرف العمارة (Foreign Key)
- ✅ `unit_number` - رقم الوحدة
- ✅ `floor` - رقم الطابق
- ✅ `type` - نوع الوحدة (apartment/shop/office)
- ✅ `facing` - واجهة الوحدة (front/back/corner)
- ✅ `area` - المساحة
- ✅ `rooms` - عدد الغرف
- ✅ `bathrooms` - عدد الحمامات
- ✅ `living_rooms` - عدد الصالات
- ✅ `kitchens` - عدد المطابخ
- ✅ `maid_room` - غرفة خادمة
- ✅ `driver_room` - غرفة سائق
- ✅ `entrances` - عدد المداخل
- ✅ `ac_type` - نوع المكيف (split/central/window)
- ✅ `status` - حالة الوحدة (available/rented/sold)
- ✅ `price` - السعر
- ✅ `description` - وصف الوحدة

---

## 🗄️ الجداول المستخدمة | Tables Used

### 1. جدول `buildings`
```sql
CREATE TABLE buildings (
  id UUID PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  plot_number VARCHAR(100),
  -- ... (37 عمود إجمالي)
  owner_association JSONB,
  floors_data JSONB,
  image_urls TEXT[],
  owner_id UUID NOT NULL REFERENCES auth.users(id)
);
```

### 2. جدول `units`
```sql
CREATE TABLE units (
  id UUID PRIMARY KEY,
  building_id UUID NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  unit_number VARCHAR(50) NOT NULL,
  floor INTEGER NOT NULL,
  -- ... (17 عمود إجمالي)
  UNIQUE(building_id, unit_number)
);
```

---

## ⚙️ السكيمات المطلوبة | Required Schemas

### ✅ جاهزة ومتوفرة في السكيما:
1. ✅ جدول buildings مع جميع الأعمدة (باستثناء address)
2. ✅ جدول units مع جميع الأعمدة
3. ✅ RLS policies لجدول buildings
4. ⚠️ RLS policies لجدول units (تحتاج تحديث)

### ⚠️ تحتاج تطبيق في Supabase:

#### 1. إضافة عمود address (اختياري)
```sql
-- نفّذ هذا إذا أردت إضافة حقل العنوان
ALTER TABLE buildings 
ADD COLUMN IF NOT EXISTS address TEXT;
```

#### 2. تحديث RLS policies لجدول units (مطلوب)
```sql
-- نفّذ الملف: fix_units_policies.sql
-- يضيف سياسات INSERT, UPDATE, DELETE للوحدات
```

---

## 🚀 خطوات التطبيق | Implementation Steps

### الخطوة 1️⃣: فتح Supabase SQL Editor
1. افتح لوحة تحكم Supabase
2. اذهب إلى SQL Editor
3. افتح تبويب جديد

### الخطوة 2️⃣: التحقق من السكيما الحالي
```sql
-- نفّذ الملف: verify_database_schema.sql
-- يعرض جميع الأعمدة والسياسات الحالية
```

### الخطوة 3️⃣: إصلاح سياسات units (مطلوب)
```sql
-- نفّذ الملف: fix_units_policies.sql
-- يضيف سياسات INSERT للوحدات
```

### الخطوة 4️⃣: إضافة عمود address (اختياري)
```sql
-- نفّذ الملف: add_address_column.sql (إن أردت)
-- ثم فعّل السطر في الكود:
-- address: `${formData.neighborhood} - قطعة ${formData.plotNumber}`,
```

---

## 🔧 حل المشاكل | Troubleshooting

### ❌ مشكلة: Could not find the 'address' column
**الحل:** عمود address معطّل حالياً في الكود. لتفعيله:
1. نفّذ `add_address_column.sql` في Supabase
2. فعّل السطر في الكود (line ~600)

### ❌ مشكلة: new row violates row-level security policy for table "units"
**الحل:** سياسات RLS لجدول units ناقصة
1. نفّذ `fix_units_policies.sql` في Supabase
2. يضيف سياسات INSERT, UPDATE, DELETE

### ❌ مشكلة: duplicate key value violates unique constraint
**الحل:** الوحدة موجودة مسبقاً
- تأكد من عدم تكرار رقم الوحدة في نفس العمارة
- حدد `UNIQUE(building_id, unit_number)`

### ❌ مشكلة: null value in column "name" violates not-null constraint
**الحل:** الحقول المطلوبة فارغة
- تأكد من ملء: اسم العمارة، رقم القطعة
- الكود يتحقق تلقائياً: `if (!formData.name || !formData.plotNumber)`

---

## 📝 ملاحظات مهمة | Important Notes

### ✅ ما يعمل حالياً:
- ✅ حفظ جميع بيانات العمارة (37 حقل)
- ✅ حفظ اتحاد الملاك (12 حقل في JSONB)
- ✅ حفظ جميع الوحدات (17 حقل لكل وحدة)
- ✅ رفع الصور وحفظ الروابط
- ✅ حساب تلقائي لعدد الطوابق والوحدات
- ✅ التحقق من صلاحيات المستخدم (RLS)

### ⚠️ يحتاج تطبيق في Supabase:
- ⚠️ سياسات RLS لجدول units (ملف: fix_units_policies.sql)
- 📋 اختياري: عمود address (ملف: add_address_column.sql)

### 🎯 الأولويات:
1. **عالية:** تطبيق fix_units_policies.sql (مطلوب للحفظ)
2. **متوسطة:** تطبيق verify_database_schema.sql (للتحقق)
3. **منخفضة:** تطبيق add_address_column.sql (اختياري)

---

## 📊 إحصائيات | Statistics

- **إجمالي الحقول المحفوظة:** 66+ حقل
  - Buildings: 37 حقل
  - Owner Association: 12 حقل (JSONB)
  - Units: 17 حقل × عدد الوحدات

- **الجداول المستخدمة:** 2
  - buildings
  - units

- **الملفات المساعدة:** 3
  - fix_units_policies.sql
  - verify_database_schema.sql
  - add_address_column.sql

---

## ✅ الخلاصة | Summary

الكود الحالي يحفظ **جميع البيانات بشكل صحيح** ✅

**المطلوب فقط:** تطبيق `fix_units_policies.sql` في Supabase لإضافة سياسات INSERT للوحدات

بعد ذلك، النظام سيعمل بشكل كامل 100% 🎉

---

📅 آخر تحديث: 2026-02-17
✍️ تم توثيق جميع البيانات والسكيمات بالكامل
