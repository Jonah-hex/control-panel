# 📊 دليل الخانات والجداول في نظام إدارة العماير

## 🏢 الجدول الأول: جدول العماير (Buildings Table)

### الخانات الأساسية:
| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف فريد للعمارة | auto-generated |
| `name` | VARCHAR(255) | اسم العمارة | عمارة النخيل |
| `address` | TEXT | عنوان العمارة | الرياض، شارع 20 |
| `description` | TEXT | وصف العمارة | عمارة سكنية حديثة |

### خانات تفاصيل المبنى:
| الخانة | النوع | وصف | القيم المحتملة |
|--------|-------|------|-----------------|
| `total_floors` | INTEGER | عدد الأدوار | 1, 2, 3... |
| `total_units` | INTEGER | إجمالي الوحدات | 0, 4, 8... |
| `reserved_units` | INTEGER | عدد الوحدات المحجوزة | 0, 1, 2... |
| `entrances` | INTEGER | عدد المداخل | 1, 2, 3... |
| `parking_slots` | INTEGER | مواقف السيارات | 0, 1, 2... |
| `elevators` | INTEGER | عدد المصاعد | 0, 1, 2... |
| `street_type` | VARCHAR(50) | نوع الشارع | 'one', 'two' |
| `building_facing` | VARCHAR(50) | اتجاه العمارة | 'north', 'south', 'east', 'west', 'northeast', 'northwest', 'southeast', 'southwest' |

### خانات معلومات التاريخ والاتصال:
| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `year_built` | INTEGER | سنة البناء | 2022 |
| `phone` | VARCHAR(20) | هاتف العمارة | 0501234567 |

### خانات معلومات الحارس:
| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `guard_name` | VARCHAR(255) | اسم الحارس | محمد أحمد |
| `guard_phone` | VARCHAR(20) | هاتف الحارس | 0505555555 |
| `guard_id_number` | VARCHAR(20) | رقم الهوية | 1234567890 |
| `guard_shift` | VARCHAR(50) | نوع الدوام | 'day', 'night', 'rotating' |

### خانات الموقع الجغرافي:
| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `latitude` | DECIMAL(10, 8) | خط العرض | 24.7136 |
| `longitude` | DECIMAL(11, 8) | خط الطول | 46.6753 |
| `google_maps_link` | TEXT | رابط Google Maps | https://maps.google.com/... |

### خانات الصور والبيانات المعقدة:
| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `image_urls` | TEXT[] | مصفوفة روابط الصور | ['url1', 'url2', 'url3'] |
| `floors_data` | JSONB | بيانات الأدوار (JSON) | {"floors": [{"number": 1, "units": [...]}]} |
| `owner_association` | JSONB | بيانات جمعية الملاك | {"hasAssociation": true, "monthlyFee": 50} |

### خانات التتبع والملكية:
| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `owner_id` | UUID | معرف المالك (المستخدم) | auto-generated |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |
| `updated_at` | TIMESTAMP | وقت آخر تحديث | 2026-02-15 14:45:00 |

---

## 🏠 الجدول الثاني: جدول الوحدات (Units Table)

### الخانات الأساسية:
| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف فريد للوحدة | auto-generated |
| `building_id` | UUID | معرف العمارة الأب | links to buildings |
| `unit_number` | VARCHAR(50) | رقم الوحدة | 101, 102, 201... |
| `floor` | INTEGER | رقم الدور | 1, 2, 3... |

### خانات نوع والمواصفات:
| الخانة | النوع | وصف | القيم المحتملة |
|--------|-------|------|-----------------|
| `type` | VARCHAR(50) | نوع الوحدة | 'apartment', 'studio', 'duplex', 'penthouse' |
| `area` | DECIMAL(8, 2) | المساحة (متر مربع) | 120.50 |
| `rooms` | INTEGER | عدد الغرف | 1, 2, 3... |
| `bathrooms` | INTEGER | عدد الحمامات | 1, 2... |
| `living_rooms` | INTEGER | عدد غرف الجلوس | 1, 2... |
| `kitchens` | INTEGER | عدد المطابخ | 1, 2... |

### خانات الغرف الإضافية:
| الخانة | النوع | وصف | القيم |
|--------|-------|------|-------|
| `maid_room` | BOOLEAN | وجود غرفة خادمة | true/false |
| `driver_room` | BOOLEAN | وجود غرفة السائق | true/false |

### خانات التكييف والحالة:
| الخانة | النوع | وصف | القيم المحتملة |
|--------|-------|------|-----------------|
| `ac_type` | VARCHAR(50) | نوع التكييف | 'split', 'window', 'splitWindow', 'central', 'none' |
| `status` | VARCHAR(50) | حالة الوحدة | 'available', 'sold', 'reserved' |
| `price` | DECIMAL(15, 2) | سعر الوحدة | 500000.00 |
| `description` | TEXT | وصف إضافي للوحدة | وحدة مشمسة، إطلالة جميلة |

### خانات التتبع:
| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |
| `updated_at` | TIMESTAMP | وقت آخر تحديث | 2026-02-15 14:45:00 |

---

## 📋 الجدول الثالث: جدول الحجوزات (Reservations Table)

| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف الحجز | auto-generated |
| `unit_id` | UUID | معرف الوحدة | links to units |
| `building_id` | UUID | معرف العمارة | links to buildings |
| `customer_name` | VARCHAR(255) | اسم العميل | أحمد محمد |
| `customer_email` | VARCHAR(255) | بريد العميل | ahmed@example.com |
| `customer_phone` | VARCHAR(20) | هاتف العميل | 0501234567 |
| `reservation_date` | TIMESTAMP | تاريخ الحجز | 2026-02-15 10:30:00 |
| `expiry_date` | TIMESTAMP | تاريخ انتهاء الحجز | 2026-05-15 10:30:00 |
| `status` | VARCHAR(50) | حالة الحجز | 'pending', 'confirmed', 'cancelled', 'completed' |
| `notes` | TEXT | ملاحظات | شروط خاصة |
| `deposit_amount` | DECIMAL(15, 2) | مبلغ التأمين | 50000.00 |
| `deposit_paid` | BOOLEAN | هل تم دفع التأمين | true/false |
| `deposit_paid_date` | TIMESTAMP | تاريخ دفع التأمين | 2026-02-15 10:30:00 |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |
| `updated_at` | TIMESTAMP | وقت آخر تحديث | 2026-02-15 14:45:00 |

---

## 💰 الجدول الرابع: جدول المبيعات (Sales Table)

| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف البيع | auto-generated |
| `unit_id` | UUID | معرف الوحدة | links to units |
| `building_id` | UUID | معرف العمارة | links to buildings |
| `buyer_name` | VARCHAR(255) | اسم المشتري | سارة أحمد |
| `buyer_email` | VARCHAR(255) | بريد المشتري | sara@example.com |
| `buyer_phone` | VARCHAR(20) | هاتف المشتري | 0502222222 |
| `buyer_id_number` | VARCHAR(20) | رقم هوية المشتري | 1234567890 |
| `sale_date` | TIMESTAMP | تاريخ البيع | 2026-02-15 10:30:00 |
| `sale_price` | DECIMAL(15, 2) | سعر البيع | 500000.00 |
| `payment_method` | VARCHAR(100) | طريقة الدفع | 'cash', 'bank_transfer', 'installment' |
| `down_payment` | DECIMAL(15, 2) | العربون | 100000.00 |
| `remaining_payment` | DECIMAL(15, 2) | المبلغ المتبقي | 400000.00 |
| `payment_status` | VARCHAR(50) | حالة الدفع | 'pending', 'partial', 'completed' |
| `contract_url` | TEXT | رابط العقد | https://storage.url/contract.pdf |
| `notes` | TEXT | ملاحظات | شروط الدفع |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |
| `updated_at` | TIMESTAMP | وقت آخر تحديث | 2026-02-15 14:45:00 |

---

## 👥 الجدول الخامس: جدول الموظفين (Staff Table)

| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف الموظف | auto-generated |
| `building_id` | UUID | معرف العمارة | links to buildings |
| `name` | VARCHAR(255) | اسم الموظف | محمد علي |
| `phone` | VARCHAR(20) | هاتف الموظف | 0505555555 |
| `id_number` | VARCHAR(20) | رقم الهوية | 1234567890 |
| `position` | VARCHAR(100) | الوظيفة | 'guard', 'cleaner', 'maintenance', 'supervisor' |
| `shift` | VARCHAR(50) | الدوام | 'day', 'night', 'rotating' |
| `hire_date` | DATE | تاريخ التوظيف | 2025-01-15 |
| `salary` | DECIMAL(10, 2) | الراتب الشهري | 2500.00 |
| `notes` | TEXT | ملاحظات | ملاحظات إضافية |
| `status` | VARCHAR(50) | الحالة | 'active', 'inactive', 'on_leave' |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |
| `updated_at` | TIMESTAMP | وقت آخر تحديث | 2026-02-15 14:45:00 |

---

## 💸 الجدول السادس: جدول المصروفات (Expenses Table)

| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف المصروفة | auto-generated |
| `building_id` | UUID | معرف العمارة | links to buildings |
| `category` | VARCHAR(100) | فئة المصروفة | 'maintenance', 'utilities', 'salary', 'cleaning', 'security', 'other' |
| `description` | TEXT | وصف المصروفة | إصلاح مكيف الهواء |
| `amount` | DECIMAL(15, 2) | المبلغ | 500.00 |
| `expense_date` | DATE | تاريخ المصروفة | 2026-02-15 |
| `payment_method` | VARCHAR(100) | طريقة الدفع | 'cash', 'bank_transfer', 'check' |
| `paid` | BOOLEAN | هل تم الدفع | true/false |
| `paid_date` | DATE | تاريخ الدفع | 2026-02-15 |
| `receipt_url` | TEXT | رابط الإيصال | https://storage.url/receipt.pdf |
| `notes` | TEXT | ملاحظات | ملاحظات إضافية |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |
| `updated_at` | TIMESTAMP | وقت آخر تحديث | 2026-02-15 14:45:00 |

---

## 💵 الجدول السابع: جدول الإيرادات (Income Table)

| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف الإيراد | auto-generated |
| `building_id` | UUID | معرف العمارة | links to buildings |
| `category` | VARCHAR(100) | فئة الإيراد | 'rent', 'sale', 'utility_fee', 'parking_fee', 'other' |
| `description` | TEXT | وصف الإيراد | إيجار شهري - وحدة 101 |
| `amount` | DECIMAL(15, 2) | المبلغ | 5000.00 |
| `income_date` | DATE | تاريخ الإيراد | 2026-02-15 |
| `payment_method` | VARCHAR(100) | طريقة الدفع | 'cash', 'bank_transfer', 'check' |
| `received` | BOOLEAN | هل تم الاستقبال | true/false |
| `received_date` | DATE | تاريخ الاستقبال | 2026-02-15 |
| `unit_id` | UUID | معرف الوحدة (اختياري) | links to units |
| `related_sale_id` | UUID | معرف البيع المرتبط (اختياري) | links to sales |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |
| `updated_at` | TIMESTAMP | وقت آخر تحديث | 2026-02-15 14:45:00 |

---

## 🔧 الجدول الثامن: جدول طلبات الصيانة (Maintenance Requests Table)

| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف الطلب | auto-generated |
| `building_id` | UUID | معرف العمارة | links to buildings |
| `unit_id` | UUID | معرف الوحدة (اختياري) | links to units |
| `title` | VARCHAR(255) | عنوان الطلب | إصلاح ماسورة ماء |
| `description` | TEXT | وصف المشكلة | تسريب من السقف |
| `priority` | VARCHAR(50) | الأولوية | 'urgent', 'high', 'normal', 'low' |
| `category` | VARCHAR(100) | نوع الصيانة | 'electrical', 'plumbing', 'hvac', 'carpentry', 'general' |
| `status` | VARCHAR(50) | حالة الطلب | 'pending', 'assigned', 'in_progress', 'completed', 'cancelled' |
| `assigned_to` | UUID | معرف الموظف المسؤول | links to staff |
| `request_date` | TIMESTAMP | تاريخ الطلب | 2026-02-15 10:30:00 |
| `scheduled_date` | DATE | تاريخ الجدول | 2026-02-20 |
| `completion_date` | DATE | تاريخ الإنجاز | 2026-02-20 |
| `estimated_cost` | DECIMAL(15, 2) | التكلفة المتوقعة | 500.00 |
| `actual_cost` | DECIMAL(15, 2) | التكلفة الفعلية | 450.00 |
| `notes` | TEXT | ملاحظات | ملاحظات إضافية |
| `completion_notes` | TEXT | ملاحظات الإنجاز | تم الإنجاز بنجاح |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |
| `updated_at` | TIMESTAMP | وقت آخر تحديث | 2026-02-15 14:45:00 |

---

## 📊 الجدول التاسع: جدول سجل الأنشطة (Activity Log Table)

| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف السجل | auto-generated |
| `building_id` | UUID | معرف العمارة | links to buildings |
| `user_id` | UUID | معرف المستخدم | links to auth.users |
| `action_type` | VARCHAR(100) | نوع الإجراء | 'create', 'update', 'delete', 'view', 'export' |
| `entity_type` | VARCHAR(100) | نوع المستند | 'building', 'unit', 'reservation', 'sale', 'expense', 'income' |
| `entity_id` | UUID | معرف المستند | links to related table |
| `description` | TEXT | وصف الإجراء | تم إنشاء وحدة جديدة |
| `changes` | JSONB | التغييرات (JSON) | {"field": "status", "before": "available", "after": "reserved"} |
| `ip_address` | VARCHAR(45) | عنوان IP | 192.168.1.1 |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |

---

## 🔔 الجدول العاشر: جدول الإخطارات (Notifications Table)

| الخانة | النوع | وصف | مثال |
|--------|-------|------|------|
| `id` | UUID | معرف الإخطار | auto-generated |
| `user_id` | UUID | معرف المستخدم | links to auth.users |
| `building_id` | UUID | معرف العمارة (اختياري) | links to buildings |
| `title` | VARCHAR(255) | عنوان الإخطار | وحدة جديدة محجوزة |
| `message` | TEXT | محتوى الإخطار | تم حجز وحدة 301 في عمارة النخيل |
| `type` | VARCHAR(50) | نوع الإخطار | 'info', 'warning', 'error', 'success' |
| `is_read` | BOOLEAN | هل تم قراءته | true/false |
| `read_at` | TIMESTAMP | وقت القراءة | 2026-02-15 10:30:00 |
| `related_entity_type` | VARCHAR(100) | نوع المستند المرتبط | 'reservation', 'sale', 'maintenance' |
| `related_entity_id` | UUID | معرف المستند المرتبط | auto-generated |
| `created_at` | TIMESTAMP | وقت الإنشاء | 2026-02-15 10:30:00 |

---

## 📌 ملاحظات مهمة:

✅ **جميع الخانات في الملف `supabase_schema.sql` جاهزة للاستخدام**  
✅ **يمكنك نسخ السكريبت مباشرة في Supabase SQL Editor**  
✅ **الفهارس موجودة لتحسين أداء الاستعلامات**  
✅ **Row Level Security مفعل لحماية البيانات**  
✅ **جميع الروابط بين الجداول معرفة بشكل صحيح**

---

## 🚀 خطوات التطبيق:

1. **انتقل إلى Supabase Dashboard**
2. **اختر مشروعك**
3. **انقر على SQL Editor**
4. **انسخ محتوى `supabase_schema.sql`**
5. **الصق في محرر SQL**
6. **انقر Execute**
7. ✅ تم! جميع الجداول جاهزة الآن
